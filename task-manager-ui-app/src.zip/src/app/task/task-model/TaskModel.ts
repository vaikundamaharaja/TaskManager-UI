
export class TaskModel{
    taskID: string;
    priority: number;
    task: string;
    parentID: string;
    startDate: string;
    endDate: string;
    
}